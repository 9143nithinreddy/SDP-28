package com.admin;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/AddBookServlet")
@MultipartConfig(maxFileSize = 16177215) // Max file size for image upload (approx. 16MB)
public class AddBookServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
        String name = request.getParameter("name");
        String author = request.getParameter("author");
        String category = request.getParameter("category");
        String price = request.getParameter("price");
        String description = request.getParameter("description");

        // Obtain the image file
        Part filePart = request.getPart("image");
        InputStream imageInputStream = null;
        if (filePart != null) {
            imageInputStream = filePart.getInputStream();
        }

        Connection conn = null;
        String message = null;

        try {
            // Database connection settings
            String dbURL = "jdbc:mysql://localhost:3306/jfsd-ps46";
            String dbUser = "root";
            String dbPassword = "12345";

            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection
            conn = DriverManager.getConnection(dbURL, dbUser, dbPassword);

            // SQL query to insert book details
            String sql = "INSERT INTO books (id, name, author, category, price, description, image) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, id);
            statement.setString(2, name);
            statement.setString(3, author);
            statement.setString(4, category);
            statement.setString(5, price);
            statement.setString(6, description);

            if (imageInputStream != null) {
                statement.setBlob(7, imageInputStream);
            }

            // Execute the query
            int row = statement.executeUpdate();
            if (row > 0) {
                message = "Book added successfully!";
            }

        } catch (Exception e) {
            e.printStackTrace();
            message = "ERROR: " + e.getMessage();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            // Set message in the request scope
            request.setAttribute("message", message);

            // Forward to the message page
            getServletContext().getRequestDispatcher("/addbook.jsp").forward(request, response);
        }
    }
}
